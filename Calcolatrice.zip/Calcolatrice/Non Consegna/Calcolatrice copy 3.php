<?php
ini_set('display_errors', 1);

class Calcolatrice 
{
    private $mathExp;
    private $cleanMathExp; //aggiornare js, per inviare stringa cosi
    private $result;
    private $errorExp;

    //TODO: non usare un texarea ma un input nel display
    //TODO: ANS
    //TODO: Ce e C
    //TODO: finire js,
    //TODO: Gestire errori --------- TESTARE
    //TODO: Memoria
    public function __construct($postExp = "radi(|2|,|radi(|2|,|2|)radf|)radf")
    {
        $this->result = 0;
        $this->mathExp = $postExp;
        $this->sanitazeExp();
        $this->errorExp = null;
        $this->expPreparer();
        
    }

    /*########################################################################*/
    /* Funzione Sanificare la stringa */
    /*########################################################################*/
    private function sanitazeExp()
    {
        $this->cleanMathExp = filter_var($this->mathExp,FILTER_SANITIZE_STRING);
    }
    /*########################################################################*/
    /* Funzione per riformattare l'array in una stringa secondo le specifiche */
    /*########################################################################*/
    private function restoreString($expArray)
    {
        $exp="";
        foreach ($expArray as $index =>$part) {
            if($index == 0 ){
                $exp .= $part."|";
            }elseif ($index == count($expArray)-1 ) {
                $exp .= $part;
            }else {
                $exp .= $part."|";
            }
        }

        return $exp;
    }
    
    /*########################################################################*/
    /* Funzione che prepara le potenze (2^2) al calcolo */
    /*########################################################################*/

    private function preparePow()
    {
        $this->cleanMathExp = str_replace ("^", "**", $this->cleanMathExp);
    }  
    /*########################################################################*/
    /* Funzione che prepara i fattoriali al calcolo */
    /*########################################################################*/
    
    private function prepareFact() //esiste funzione gmp_fact;
    {
        $tempExp = $this->cleanMathExp;
        $expArray = explode("|",$tempExp);
        for ($i=0; $i < count($expArray); $i++) {
            if ($expArray[$i] == "!" && is_numeric($expArray[$i-1])) {
                $fact = 1;
                $num = $expArray[$i-1];

                for ($j=0; $j < $num; $j++) { 
                    $fact *= $num -$j;
                }


                unset($expArray[$i-1]);
                $expArray[$i] =  $fact;
                $expArray = array_values($expArray);
                $this->cleanMathExp = $this->restoreString($expArray);   

            }
        }    
    }
    /*########################################################################*/
    /* Funzione che prepara le radici (rad(3,1/3)) al calcolo */
    /*########################################################################*/

    
    private function prepareRad() //tenere conto di un possible calcolo Rad(rad(2,2),33)
    {
        $tempExp = $this->cleanMathExp;
        $expArray = explode("|",$tempExp);

        //Ordinamento delle radici (elevato,numero) per ottenere un risultato come questo (numero,elevato)
        //i e = alla lunghezza del array
        $i = count($expArray)-1;
        while ($i >=0) {

            //se trovo l'inizio di una radice
           if(substr_count($expArray[$i],"radi")==1){
                $randfPos=$i;
                $randiPos=$i;
                $virgolaPos = $i;

                //trovo la fine della radice
                while ($expArray[$randfPos] != ")radf" && $randfPos < count($expArray)-1) {
                    $randfPos++;

                }

                //trovo la posizione della virgola
                while ($expArray[$virgolaPos] != "," && $virgolaPos < count($expArray)-1) {
                    $virgolaPos++;                
                }

                //salvo la parte del elvato e la parte del numero in 2 array differenti
                $partRadice1 =[];
                $partRadice2 =[];
                
                for ($j=$randiPos+1; $j < $virgolaPos ;$j++) { 
                     array_push($partRadice1, $expArray[$j]);
                }
                for ($j=$virgolaPos+1; $j < $randfPos ;$j++) { 
                    array_push($partRadice2, $expArray[$j]);
               }

                //sostituzione in array usare sub string

                //uso un array di supporto per caricare il nuovo array con numero è elvato invertiti
                $completeExp = [];

                //inizio array
                for ($j=0; $j < $randiPos; $j++) { 
                    array_push($completeExp, $expArray[$j]); 
                }
                //fino al inizio della radice
                //inserisco l'apertura della radice
                array_push($completeExp, "pow("); 
                //aggiungo anche il secondo array
                for ($j=0; $j <  count($partRadice2); $j++) { 
                    array_push($completeExp, $partRadice2[$j]); 
                }
                //inserisco una virgloa
                array_push($completeExp, ","); 
                //aggiungo anche il primo array
                array_push($completeExp, "1/("); 
                for ($j=0; $j < count($partRadice1); $j++) { 
                    array_push($completeExp, $partRadice1[$j]); 
                }
                //inserisco la chiusura della radice
                array_push($completeExp, "))"); 
                //completo l'array con il restante dell array principale (expArray)
                for ($j=$randfPos+1; $j < count($expArray); $j++) { 
                    array_push($completeExp, $expArray[$j]); 
                }
                //Aggiorno l'array principale con la radice aggiornata              
                $expArray = $completeExp;
                //aggiorno l'indice con la nuova dimensione del array
                $i = count($expArray)-1;
            }
            $i--;
            //ripeto finche ci sono radici
        }

       $this->cleanMathExp = $this->restoreString($expArray);    
    }

    /*########################################################################*/
    /* Funzione che prepara le restanti funzioni al calcolo*/
    /*########################################################################*/
    private function prepareFuncAndNumber()
    {
        $tempExp = $this->cleanMathExp;
        $expArray = explode("|",$tempExp);
        for ($i=0; $i < count($expArray); $i++) {
            if ($expArray[$i-1] == "π" && $expArray[$i] != "," && $expArray[$i] != ")" &&$expArray[$i] != "+" && $expArray[$i] != "-" && $expArray[$i] != "*" && $expArray[$i] != "/" ) {
                $expArray[$i] = "|*|".$expArray[$i];
            } 
            switch ($expArray[$i]) {
                case 'rec(':
                    $expArray[$i] = "1/(";
                    break;
                case 'π':
                    if ($i > 0 && substr_count($expArray[$i-1],"(")== 0 &&$expArray[$i-1] != "+" && $expArray[$i-1] != "-" && $expArray[$i-1] != "*" && $expArray[$i-1] != "/") {
                        $expArray[$i] = "|*|".pi();
                    }else{
                        $expArray[$i] = pi();
                    }
                    if ($expArray[$i+1] != "," && $expArray[$i+1] != ")" &&$expArray[$i+1] != "+" && $expArray[$i+1] != "-" && $expArray[$i+1] != "*" && $expArray[$i+1] != "/" ) {
                        $expArray[$i] .= "|*|"; 
                    }
                    break;   
                
               case 'sqrt(':
                    if ($i > 0 && substr_count($expArray[$i-1],"(")== 0 &&$expArray[$i-1] != "+" && $expArray[$i-1] != "-" && $expArray[$i-1] != "*" && $expArray[$i-1] != "/") {
                        $expArray[$i] = "|*|sqrt(";
                    }else{
                        $expArray[$i] = "sqrt(";
                    }               
                    break;       
                 
                default:
                    break;
            }          
        }
        
        $this->cleanMathExp = $this->restoreString($expArray);   

    }

    public function getErrorExp()
    {        
        return $this->errorExp;
    }
    public function getResultExp()
    {        
        return $this->result;
    }

    private function defineErrorEpx()
    { 
        if (substr_count($this->errorExp,"syntax error")>0 ) {
            $this->errorExp =  "Syntax error";
        }else if (substr_count($this->errorExp,"Call to undefined")>0 ) {
            $this->errorExp =  "Syntax error";
        }else if($this->errorExp == "Division by zero"){
            $this->errorExp = "Division by zero";
        }else if(is_nan($this->result)){
            $this->errorExp = "Math error";
        }
    }
    /*########################################################################*/
    /* Funzione effetua il calcolo*/
    /*########################################################################*/
    private function expPreparer()
    {
        function e($errno, $errstr, $errfile, $errline) {
            if ($errstr == "Division by zero") {
                throw new Exception($errstr, $errno);
            }
                
        }
        
        set_error_handler('e');

        //create cotan function
        function cotan($tan)
        {
            return 1/(tan($tan));
        }

        
        $this->preparePow();
        $this->prepareRad();
        $this->prepareFuncAndNumber();
        $this->prepareFact();
        $tempExp = $this->cleanMathExp;
        $expArray = explode("|",$tempExp);
        $finalExp = "";
        foreach ($expArray as $part) {
                $finalExp .=$part;
        }
        echo $finalExp;
 
        try {
            $result = "";
            eval('$result = '. $finalExp .';');
            $this->result = $result;
        } catch (\Throwable $th) {
            $this->errorExp = $th->getMessage();

        }
        $this->defineErrorEpx(); 
    }
}


//gestire se calcolo supera massimo della memoria
//echo pow(2,pow(2,pow(2,9)));



?>