/*
 *   Copyright (c) 2020
 *   All rights reserved.
 */
/**funzioni
 * segni V
 * numeri V
 * funzioni V
 * radici V
 * esponenti V
 * Todo: controllare se le funzioni create funzionano  e creare funzione display
 * * Valutare se introdurre un counter per le parentesi ) nel caso in cui si voglia aggiungere una parentesi fantasma quando l'utente apre le parentesi
 * * meno
 * vedere ( 1/n )
 * ans
 * display (stampa sul display ed aggiunge il numero o simili all'eq)
 *  Funzionamenti V
 * il numero di base è = 0 in caso venga inserito un numero != da 0
 *  il numero 0 viene sostituito solo se la stringa e lunga 1 carattere
 *
 */

//Funzioni Di Comodo

//funzioni calcolatrice
function segni(segno) {
  FORMeqValue = document.getElementById("FORMeqObj").value; //oggetto input nascosto del form
  if (
    FORMeqValue.charAt(FORMeqValue.length - 1) != "+" &&
    FORMeqValue.charAt(FORMeqValue.length - 1) != "-" &&
    FORMeqValue.charAt(FORMeqValue.length - 1) != "." &&
    FORMeqValue.charAt(FORMeqValue.length - 1) != "÷" &&
    FORMeqValue.charAt(FORMeqValue.length - 1) != "×" &&
    FORMeqValue.charAt(FORMeqValue.length - 1) != "" &&
    FORMeqValue.charAt(FORMeqValue.length - 1) != ")" &&
    FORMeqValue.charAt(FORMeqValue.length - 1) != "("
  ) {
    display(segno);
  } else if (
    FORMeqValue.charAt(FORMeqValue.length - 1) == ")" &&
    segno == "."
  ) {
    //non fa nulla
  }
}
function funzMatematiche(funzione) {
  FORMeqValue = document.getElementById("FORMeqObj").value; //oggetto input nascosto del form

  if (
    FORMeqValue.charAt(FORMeqValue.length - 1) == "0" &&
    FORMeqValue.length == 1
  ) {
    display(funzione, 0);
    //(funzione(, indice carattere da eliminare nella stringa in questo caso 0, visto che il primo numero del eq è 0))
  } else {
    if (
      FORMeqValue.charAt(FORMeqValue.length - 1) != "+" &&
      FORMeqValue.charAt(FORMeqValue.length - 1) != "-" &&
      FORMeqValue.charAt(FORMeqValue.length - 1) != "÷" &&
      FORMeqValue.charAt(FORMeqValue.length - 1) != "×" &&
      FORMeqValue.charAt(FORMeqValue.length - 1) != "("
    ) {
      display("×" + funzione); //funzione display (x funzione() //aggiunge segno per
    } else if (FORMeqValue.charAt(FORMeqValue.length - 1) == ".") {
      //non fa nulla
    } else {
      display(funzione);
    }
  }
}
function Radici(radice) {
  FORMeqValue = document.getElementById("FORMeqObj").value; //oggetto input nascosto del form
  switch (radice) {
    case "√^2":
      radice = "√^2(";
      break;
    case "√^n":
      radice = "√^";
      break;
    default:
      break;
  }

  if (
    FORMeqValue.charAt(FORMeqValue.length - 1) == "0" &&
    FORMeqValue.length == 1
  ) {
    display(radice, 0);
    //funzione display (radice(, indice carattere da eliminare nella stringa in questo caso 0, visto che il primo numero del eq è 0))
  } else {
    if (
      FORMeqValue.charAt(FORMeqValue.length - 1) != "+" &&
      FORMeqValue.charAt(FORMeqValue.length - 1) != "-" &&
      FORMeqValue.charAt(FORMeqValue.length - 1) != "÷" &&
      FORMeqValue.charAt(FORMeqValue.length - 1) != "×"
    ) {
      display("×" + radice);
      //funzione display (x radice() //aggiunge segno per
    } else if (FORMeqValue.charAt(FORMeqValue.length - 1) == ".") {
      //non fa nulla
    } else {
      display(radice);
    }
  }
}

function esponenti(esponente) {
  FORMeqValue = document.getElementById("FORMeqObj").value; //oggetto input nascosto del form
  switch (esponente) {
    case "x²":
      esponente = "²";
      break;
    case "x^n":
      esponente = "^";
      break;
    default:
      break;
  }
  if (
    FORMeqValue.charAt(FORMeqValue.length - 1) != "+" &&
    FORMeqValue.charAt(FORMeqValue.length - 1) != "-" &&
    FORMeqValue.charAt(FORMeqValue.length - 1) != "." &&
    FORMeqValue.charAt(FORMeqValue.length - 1) != "÷" &&
    FORMeqValue.charAt(FORMeqValue.length - 1) != "×" &&
    FORMeqValue.charAt(FORMeqValue.length - 1) != "" &&
    FORMeqValue.charAt(FORMeqValue.length - 1) != "(" &&
    FORMeqValue.charAt(FORMeqValue.length - 1) != "^" &&
    FORMeqValue.charAt(FORMeqValue.length - 1) != "²"
  ) {
    display(esponente);
  } else {
    //non fa nulla
  }
}
function number(numero) {
  FORMeqValue = document.getElementById("FORMeqObj").value; //oggetto input nascosto del form
  if (
    FORMeqValue.charAt(FORMeqValue.length - 1) == "0" &&
    FORMeqValue.length == 1 &&
    numero != "0"
  ) {
    //funzione display (numero, indice carattere da eliminare nella stringa in questo caso 0, visto che il primo numero del eq è 0))
    display(numero, 0);
  } else if (FORMeqValue.charAt(FORMeqValue.length - 1) == "²") {
    // ToDO se possibile controllare anche quando ce x^n e π
    display("×"+numero);
  } else {
    //funzione display (numero)
    display(numero);
  }
}
function Parentesi(parentesi) {
  FORMeqValue = document.getElementById("FORMeqObj").value; //oggetto input nascosto del form
  if (parentesi == ")") {
    console.log(FORMeqValue.length);
    if (
      FORMeqValue.charAt(FORMeqValue.length - 1) != "+" &&
      FORMeqValue.charAt(FORMeqValue.length - 1) != "-" &&
      FORMeqValue.charAt(FORMeqValue.length - 1) != "÷" &&
      FORMeqValue.charAt(FORMeqValue.length - 1) != "×" &&
      FORMeqValue.charAt(FORMeqValue.length - 1) != "."
    ) {
      display(parentesi);
    }
  } else if (parentesi == "(") {
    if (
      FORMeqValue.charAt(FORMeqValue.length - 1) != "+" &&
      FORMeqValue.charAt(FORMeqValue.length - 1) != "-" &&
      FORMeqValue.charAt(FORMeqValue.length - 1) != "÷" &&
      FORMeqValue.charAt(FORMeqValue.length - 1) != "×" &&
      FORMeqValue.charAt(FORMeqValue.length - 1) != "(" &&
      FORMeqValue.charAt(FORMeqValue.length - 1) != "."
    ) {
      display("×" + parentesi);
    } else {
      display(parentesi);
    }
  }
}
function display(text, hiddentext = text, indice = null) {
  console.log("calc");
  FORMeq = document.getElementById("FORMeqObj"); //oggetto input nascosto del form
  eqString = document.getElementById("Exp");
  if (indice != null) {
    tempHiddenText = FORMeq.value;
    tempHiddenText = hiddentext + tempHiddenText.substr(indice + hiddentext.length);
    
    tempText = eqString.innerHTML;
    tempText = text + tempText.substr(indice + text.length);
    
    FORMeq.value = tempHiddenText;
    eqString.value = tempText;
  } else {
    FORMeq.value += hiddentext;
    eqString.innerHTML += text;
  }
}
