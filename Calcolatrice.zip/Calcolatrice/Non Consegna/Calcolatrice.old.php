<?php
class calcProcessing
{
    private $mathExpression;
    private $CleanmathExpression;
    public function __construct($mathDirtString)
    {
        $this->mathExpression = $mathDirtString;
        $this->postTranslatorAndSanizer();
        echo $this->CleanmathExpression;
        // 
    }
    public function postTranslatorAndSanizer()
    {
        $this->CleanmathExpression =  preg_replace('/\s+/', '', $this->mathExpression); //Rimuovo gli spazzi vuoti
        $numCharAmmessi = '(?:\d+(?:[,.]\d+)?|pi|π)'; //definisco i numeri / caratteri validi
        //!rivedere funzioni ammesse
        $funzioniAmmesse = '(?:sinh?|cosh?|tanh?|abs|acosh?|asinh?|√^?|atanh?|exp|log10|deg2rad|rad2deg|sqrt|ceil|floor|round)'; //definisco le funzioni valide
        $operatoriValidi =  '[+\/x\^-]'; //definisco gli operatori validi
        $RegexCompleto = '/^((' . $numCharAmmessi . '|' . $funzioniAmmesse . '\s*\((?1)+\)|\((?1)+\))(?:' . $operatoriValidi . '(?2))?)+$/';  //Regola RegEx Completa
        if (preg_match($RegexCompleto, $this->CleanmathExpression)) {
            $this->CleanmathExpression = preg_replace('/pi|π/', 'pi()', $this->CleanmathExpression); //converto il carattere del pigreco nella funzione pi() di php
            $this->CleanmathExpression =  preg_replace('/x/', '*', $this->mathExpression);
            for ($i=0; $i < count($this->CleanmathExpression); $i++) { 
                if ($this->CleanmathExpression[$i] == "^") {
                    $j = $i;
                    while ($this->CleanmathExpression[$j] != "(" || $this->CleanmathExpression[$j] != "+" || $this->CleanmathExpression[$j] != "-" || $this->CleanmathExpression[$j] != "/" || $this->CleanmathExpression[$j] != "*" || $this->CleanmathExpression[$j] != "^" ) {
                        $j--;
                    }
                    $tmpString = substr($this->CleanmathExpression, 0, $j-1)."pow(".substr($this->CleanmathExpression,$j-1);

                }
            }
            


        } else {
            echo $this->CleanmathExpression;
            $this->CleanmathExpression = "badInput";
        }
    }

  
    public function getCalcSolution()
    {
        $result = "";
        //echo  $this->CleanmathExpression;
        eval('$result = ' . $this->CleanmathExpression . ';');
        return $result;
    }
}
$a = new calcProcessing("2^3^4^5^6");
echo $a->getCalcSolution();











/*










private function EvalPurifier($mathDirtString)
{
    //Anti-Inject Filter : Utilizzo espressioni RegEx per convalidare i dati.
    $mathDirtString =  preg_replace('/\s+/', '', $mathDirtString); //Rimuovo gli spazzi vuoti
    $numCharAmmessi = '(?:\d+(?:[,.]\d+)?|pi|π)'; //definisco i numeri / caratteri validi
    $funzioniAmmesse = '(?:sinh?|cosh?|tanh?|abs|acosh?|asinh?|atanh?|exp|log10|deg2rad|rad2deg|sqrt|ceil|floor|round)'; //definisco le funzioni valide
    $operatoriValidi =  '[+\/x\^%-]'; //definisco gli operatori validi
    $RegexCompleto = '/^((' . $numCharAmmessi . '|' . $funzioniAmmesse . '\s*\((?1)+\)|\((?1)+\))(?:' . $operatoriValidi . '(?2))?)+$/';  //Regola RegEx Completa
    if (preg_match($RegexCompleto, $mathDirtString)) {
        $mathDirtString = preg_replace('!pi|π', 'pi()', $mathDirtString); //converto il carattere del pigreco nella funzione pi() di php
    } else {
        echo $mathDirtString;
        $mathDirtString = "badInput";
        
    }
    return $mathDirtString;
}

*/