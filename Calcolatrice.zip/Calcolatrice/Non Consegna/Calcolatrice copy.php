<?php
ini_set('display_errors', 1);
class Calcolatrice 
{
    private $mathExp;
    private $cleanMathExp ="radi(|2|,|2|)radf|^|2"; //aggiornare js, per inviare stringa cosi

    //TODO: non usare un texarea ma un input nel display
    //TODO: ANS
    //TODO: Ce e C
    //TODO: finire js,
    //TODO: Pigreco, 
    //TODO: fare reciproco e fattoriale
    //TODO: Gestire errori
    //TODO: Memoria
    //TODO: Sanificazione
    public function __construct($postExp)
    {
        //assign to exp
        //Sanitize string (clean exp)

    }
    /*########################################################################*/
    /* Funzione per riformattare l'array in una stringa secondo le specifiche */
    /*########################################################################*/

    private function restoreString($expArray)
    {
        $exp="";
        foreach ($expArray as $index =>$part) {
            if($index == 0 ){
                $exp .= $part."|";
            }elseif ($index == count($expArray)-1 ) {
                $exp .= $part;
            }else {
                $exp .= $part."|";
            }
        }

        return $exp;
    }
    
    /*########################################################################*/
    /* Funzione che prepara le potenze (2^2) al calcolo */
    /*########################################################################*/
   /* private function preparePow()
    {
        //$tempExp = "rad(|1|,|2|)"; // sostituire con attributo clean exp
        $tempExp = $this->cleanMathExp;
        $expArray = explode("|",$tempExp);
        /*pow
        $string ="";
        
        $parentesi = 0;
        for ($i= 0; $i<count($expArray) ; $i++) {
            //echo $expArray[$i];
            if ($expArray[$i] == "^") {
                $j = $i;
                $l = $i;
                $expArray[$i] = "A";
                $parentesi++;
                while (!is_numeric($expArray[$j])) {
                   $j++;
                }
                /*while (!is_numeric($expArray[$l])) { //cambiare, non cercare un numero ma il prossimo segno di fine come un + un - o simili
                    $l--;
                 }

                while (!is_numeric($expArray[$l])) { //cambiare, non cercare un numero ma il prossimo segno di fine come un + un - o simili
                    $l--;
                 }


                
                $string .= "pow(".$expArray[$l].",";
                $expArray[$l] = "F";
                if ($j+1 < count($expArray) && $expArray[$j+1] == "^") {
                }else {
                    $string .= $expArray[$j];
                    $expArray[$j] = "F";
                    for ($p=0; $p < $parentesi; $p++) { 
                        $string .= ")";
                    }
                    $this->partialFinalExp += [$i => $string]; 
                    $string = "";

                    $parentesi=0;
                }                 
            }
        }
        $this->cleanMathExp = $this->restoreString($expArray);   
    }*/

    private function preparePow()
    {
        $tempExp = $this->cleanMathExp;
        $expArray = explode("|",$tempExp);

        for ($i=0; $i < count($expArray)-1; $i++) { 
            if ($expArray[$i] == "^") {
                $expArray[$i] = "**";
            }
        }
        $this->cleanMathExp = $this->restoreString($expArray);   
    }    
    /*########################################################################*/
    /* Funzione che prepara le radici (rad(3,1/3)) al calcolo */
    /*########################################################################*/

    private function prepareRad() //tenere conto di un possible calcolo Rad(rad(2,2),33)
    {
        $tempExp = $this->cleanMathExp;
        $expArray = explode("|",$tempExp);

        //Ordinamento delle radici (elevato,numero) per ottenere un risultato come questo (numero,elevato)
        //i e = alla lunghezza del array
        $i = count($expArray)-1;
        while ($i >=0) {

            //se trovo l'inizio di una radice
           if(substr_count($expArray[$i],"radi")==1){
                $randfPos=$i;
                $randiPos=$i;
                $virgolaPos = $i;

                //trovo la fine della radice
                while ($expArray[$randfPos] != ")radf" && $randfPos < count($expArray)-1) {
                    $randfPos++;

                }

                //trovo la posizione della virgola
                while ($expArray[$virgolaPos] != "," && $virgolaPos < count($expArray)-1) {
                    $virgolaPos++;                
                }

                //salvo la parte del elvato e la parte del numero in 2 array differenti
                $partRadice1 =[];
                $partRadice2 =[];
                
                for ($j=$randiPos+1; $j < $virgolaPos ;$j++) { 
                     array_push($partRadice1, $expArray[$j]);
                }
                for ($j=$virgolaPos+1; $j < $randfPos ;$j++) { 
                    array_push($partRadice2, $expArray[$j]);
               }

                //sostituzione in array usare sub string

                //uso un array di supporto per caricare il nuovo array con numero è elvato invertiti
                $completeExp = [];

                //inizio array
                for ($j=0; $j < $randiPos; $j++) { 
                    array_push($completeExp, $expArray[$j]); 
                }
                //fino al inizio della radice
                //inserisco l'apertura della radice
                array_push($completeExp, "pow("); 
                //aggiungo anche il secondo array
                for ($j=0; $j <  count($partRadice2); $j++) { 
                    array_push($completeExp, $partRadice2[$j]); 
                }
                //inserisco una virgloa
                array_push($completeExp, ","); 
                //aggiungo anche il primo array
                array_push($completeExp, "1/("); 
                for ($j=0; $j < count($partRadice1); $j++) { 
                    array_push($completeExp, $partRadice1[$j]); 
                }
                //inserisco la chiusura della radice
                array_push($completeExp, "))"); 
                //completo l'array con il restante dell array principale (expArray)
                for ($j=$randfPos+1; $j < count($expArray); $j++) { 
                    array_push($completeExp, $expArray[$j]); 
                }
                //Aggiorno l'array principale con la radice aggiornata              
                $expArray = $completeExp;
                //aggiorno l'indice con la nuova dimensione del array
                $i = count($expArray)-1;
            }
            $i--;
            //ripeto finche ci sono radici
        }

       $this->cleanMathExp = $this->restoreString($expArray);    
    }

    /*########################################################################*/
    /* Funzione che prepara le restanti funzioni al calcolo*/
    /*########################################################################*/
   /* private function prepareFuncAndNumber()
    {
        $tempExp = $this->cleanMathExp;
        $expArray = explode("|",$tempExp);

        foreach ($expArray as $index => $part) {
            if ($part != "A" && $part != "F") {
                $this->partialFinalExp += [$index => $part]; 
            }
        }
        $this->cleanMathExp = $this->restoreString($expArray);   
    }*/
    private function prepareFuncAndNumber()
    {
        $tempExp = $this->cleanMathExp;
        $expArray = explode("|",$tempExp);
        
        $this->cleanMathExp = $this->restoreString($expArray);   

    }
    /*########################################################################*/
    /* Funzione effetua il calcolo*/
    /*########################################################################*/
    public function expPreparer()
    {
        $this->preparePow();
        $this->prepareRad();
        $this->prepareFuncAndNumber();
        $tempExp = $this->cleanMathExp;
        $expArray = explode("|",$tempExp);
        $finalExp = "";
        foreach ($expArray as $part) {
                $finalExp .=$part;
        }

 
        echo $finalExp;
        $result = 0;
        eval('$result= '. $finalExp .';');
        echo $result;
       
    }
}


//gestire se calcolo supera massimo della memoria
//echo pow(2,pow(2,pow(2,9)));
$a = new Calcolatrice("dd");
$a->expPreparer();



?>