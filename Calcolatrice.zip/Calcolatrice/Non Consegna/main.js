/*
 *   Copyright (c) 2020
 *   All rights reserved.
 */

/**
 * TODO:
 *  TODO: POST
 *  TODO: EQ STRING
 *  TODO: EQ RESULT
 *  TODO: MEM
 *  TODO: CSS AFTER PER CHIUSA ) FANTASMA
 * 
 * !continuare in REmain
 *
 *
 */

//sin con
function conParentesi(keyObj) {
  FORMeqObj = document.getElementById("FORMeqObj"); //dato form nascosto
  // * !FORMeqObj a display vuoto risulta undefined quindi da errore e non scrive nulla
  //* TODO: Verificare se FORMeqObj è undefined o no
  if (FORMeqObj.value == undefined) {
    formobjString = "";
  }else {
    formobjString = FORMeqObj.value;
  }

  if (
    formobjString.charAt(formobjString.length - 1) != "+" &&
    formobjString.charAt(formobjString.length - 1) != "-" &&
    formobjString.charAt(formobjString.length - 1) != "÷" &&
    formobjString.charAt(formobjString.length - 1) != "×" &&
    formobjString.charAt(formobjString.length - 1) != "%" &&
    formobjString.charAt(formobjString.length - 1) != "" &&
    formobjString.charAt(formobjString.length - 1) != "("
  ) {
    eqCreator(keyObj, "×", true);
  } else {
    eqCreator(keyObj, "", true);
  }
}

//segni come (
function precedutoDaSegno(keyObj) {
  FORMeqObj = document.getElementById("FORMeqObj"); //dato form nascosto
  // !FORMeqObj a display vuoto risulta undefined quindi da errore e non scrive nulla
  //TODO: Verificare se FORMeqObj è undefined o no
  if (FORMeqObj.value == undefined) {
    formobjString = "";
  } else {
    formobjString = FORMeqObj.value;
  }
  if (formobjString.charAt(formobjString.length - 1) != "+" &&
    formobjString.charAt(formobjString.length - 1) != "-" &&
    formobjString.charAt(formobjString.length - 1) != "÷" &&
    formobjString.charAt(formobjString.length - 1) != "×" &&
    formobjString.charAt(formobjString.length - 1) != "%" &&
    formobjString.charAt(formobjString.length - 1) != "" &&
    formobjString.charAt(formobjString.length - 1) != "("
  ) {
    eqCreator(keyObj, "×", false);
  } else {
    eqCreator(keyObj, "", false);
  }
}

//controllo operatori + * - / %
function cOp(keyObj) {
  //controlOperator
  //TODO: risolvere problema virgola
  FORMeqObj = document.getElementById("FORMeqObj");
  if (FORMeqObj.value == undefined) {
    formobjString = "";
  } else {
    formobjString = FORMeqObj.value;
  }
  if (
    formobjString.charAt(formobjString.length - 1) != "+" &&
    formobjString.charAt(formobjString.length - 1) != "-" &&
    formobjString.charAt(formobjString.length - 1) != "." &&
    formobjString.charAt(formobjString.length - 1) != "÷" &&
    formobjString.charAt(formobjString.length - 1) != "×" &&
    formobjString.charAt(formobjString.length - 1) != "%" &&
    formobjString.charAt(formobjString.length - 1) != "" &&
    formobjString.charAt(formobjString.length - 1) != ")" &&
    formobjString.charAt(formobjString.length - 1) != "("
  ) {
    eqCreator(keyObj);
  } else if (
    formobjString.charAt(formobjString.length - 1) == ")" &&
    keyObj.value == "."
  ) {
  }
}

//creatore del eq principale
function eqCreator(keyObj, altSign = "", isParentesi = false) {
  var eqString = "";
  eqObj = document.getElementById("eqString"); //display
  FORMeqObj = document.getElementById("FORMeqObj"); //dato form nascosto
  console.log(FORMeqObj.value.charAt(FORMeqObj.value.length - 1))

  if (isParentesi) {
    parentesi = "(";
  } else {
    parentesi = "";
  }
  switch (keyObj.value) {
    case 'x²':
      keyValue = '²';
      break;
    default:
      keyValue = keyObj.value;
      break;
  }
  if (FORMeqObj.value == undefined) {
    eqString = "" + keyObj.value + parentesi;
  } else {
    eqString = FORMeqObj.value + altSign + keyObj.value + parentesi;
  }

  eqObj.innerText = eqString;
  FORMeqObj.value = eqString;
}
//TODO: Aggiungere segni mancanti e funzioni matematiche mancanti
