/*
 *   Copyright (c) 2020 
 *   All rights reserved.
 */

var alreadyPoint = false;
var haveParentesi = [];

function op(operator) {
    disExpOBJ = document.getElementById("disExp");
    var calcOp;
    var disOp;

    lastChar = disExpOBJ.value.charAt(disExpOBJ.value.length - 1);
    console.log(lastChar)

    if (lastChar != "^" &&lastChar != "." && lastChar != "+" && lastChar != "-" && lastChar != "x" && lastChar != "/" || lastChar == ")") {
        alreadyPoint = false;
        calcOp = "|"+operator;
        disOp = operator;
    }else{
        calcOp = "";
        disOp = "";
    }
    display(calcOp, disOp)
}

function num(numero) {
    disExpOBJ = document.getElementById("disExp");
    var calcNum;
    var disNum;

    lastChar = disExpOBJ.value.charAt(disExpOBJ.value.length - 1);

    if (numero == "π"|| lastChar == "π" ||lastChar == "(" || lastChar == "+" || lastChar == "-" || lastChar == "x" || lastChar == "/") {
        calcNum = "|"+numero;
        disNum = numero;
    }else if (lastChar == ")" || lastChar == "S") {
        calcNum = "|*|"+numero;
        disNum = numero;
    }else{
        calcNum = numero;
        disNum = numero;
    }
    display(calcNum, disNum)

}
function funzioniBase(funzione) {
    disExpOBJ = document.getElementById("disExp");
    var calcNum;
    var disNum;
    lastChar = disExpOBJ.value.charAt(disExpOBJ.value.length - 1);

    if (disExpOBJ.value.length > 0 && lastChar != "(" && lastChar != "+" && lastChar != "-" && lastChar != "x" && lastChar != "/") {
        alreadyPoint = false;
        calcNum = "|*|"+funzione;
        disNum = funzione; //mettere parentesi fittizia
        haveParentesi.unshift(")");
    }else{
        alreadyPoint = false;
        calcNum = "|"+funzione;
        disNum = funzione; //mettere parentesi fittizia
        haveParentesi.unshift(")");
    }
    display(calcNum, disNum)
}
function parentesi(paretesi) {
    disExpOBJ = document.getElementById("disExp");
    var calcNum;
    var disNum;
    lastChar = disExpOBJ.value.charAt(disExpOBJ.value.length - 1);

    switch (paretesi) {
        case "(":
            if (disExpOBJ.value.length > 0 && lastChar != "(" && lastChar != "+" && lastChar != "-" && lastChar != "x" && lastChar != "/") {
                calcNum = "|*|(";
                disNum = "(";
            }else{
                calcNum = "|(";
                disNum = "(";
            }
            if (haveParentesi[0] == "(") {
                haveParentesi.splice(0,1);
            }else if(haveParentesi[0] == ","){
                haveParentesi.splice(0,1);
                calcNum = "|,";
            }
            alreadyPoint = false;
            haveParentesi.unshift(")");
            display(calcNum, disNum)
            break;
        case ")":
            calcNum = "|)";
            disNum = ")";
            if (haveParentesi[0] == ")") {
                haveParentesi.splice(0,1);
            }
            alreadyPoint = false;
            display(calcNum, disNum)
            break;
        default:
            break;
    }

    

}
function potenza(potenza) {
    disExpOBJ = document.getElementById("disExp");
    var calcNum;
    var disNum;
    lastChar = disExpOBJ.value.charAt(disExpOBJ.value.length - 1);
    if (lastChar != "." && lastChar != "+" && lastChar != "-" && lastChar != "x" && lastChar != "/") {
        alreadyPoint = false;
        switch (potenza) {
            case "x²":
                calcNum = "|^|2";
                disNum = "^2"; //mettere parentesi fittizia
                break;
            case "x^n":
                calcNum = "|^|";
                disNum = "^"; //mettere parentesi fittizia
                break;
            default:
                break;
            }

                display(calcNum, disNum);
            }

}
function rad(radice) {
    disExpOBJ = document.getElementById("disExp");
    var calcNum;
    var disNum;
    lastChar = disExpOBJ.value.charAt(disExpOBJ.value.length - 1);

    //risolvere parentesi
    switch (radice) {
        case "√^2":
            alreadyPoint = false;
            calcNum = "|sqrt(|";
            disNum = radice+"(";
            haveParentesi.unshift(")");
            break;
        case "√^n":
            alreadyPoint = false;
            if (disExpOBJ.value.length > 0 && lastChar != "(" &&lastChar != "^" && lastChar != "+" && lastChar != "-" && lastChar != "x" && lastChar != "/") {
                calcNum = "|*|radn(|";
                disNum = "√^"; //mettere parentesi fittizia
                haveParentesi.unshift(",");
            }else{
                calcNum = "|radn(|";
                disNum = "√^"; //mettere parentesi fittizia
                haveParentesi.unshift(",");
            }
            break;
        default:
            break;
    }
    display(calcNum, disNum)
}

function reciproco() {
    disExpOBJ = document.getElementById("disExp");
    var calcNum;
    var disNum;
    lastChar = disExpOBJ.value.charAt(disExpOBJ.value.length - 1);
    if (disExpOBJ.value.length > 0 && lastChar != "(" && lastChar != "+" && lastChar != "-" && lastChar != "x" && lastChar != "/") {
        alreadyPoint = false;
        calcNum = "|*|rec(|";
        disNum = "rec("; //mettere parentesi fittizia
    }else{
        alreadyPoint = false;
        calcNum = "|rec(|";
        disNum = "rec("; //mettere parentesi fittizia
    }
    haveParentesi.unshift(")");

    display(calcNum, disNum)
}
function fattoriale() {
    disExpOBJ = document.getElementById("disExp");
    var calcNum;
    var disNum;
    lastChar = disExpOBJ.value.charAt(disExpOBJ.value.length - 1);
    if (disExpOBJ.value.length > 0 && !isNaN(lastChar)) {
        calcNum = "|!";
        disNum = "!"; //mettere parentesi fittizia
        alreadyPoint = true;
        display(calcNum, disNum)
    }    
}
function point() {
    disExpOBJ = document.getElementById("disExp");
    var calcNum;
    var disNum;
    lastChar = disExpOBJ.value.charAt(disExpOBJ.value.length - 1);

    if (!isNaN(lastChar) && alreadyPoint == false) {
        calcNum = ".";
        disNum = "."; //mettere parentesi fittizia
        alreadyPoint = true;
        display(calcNum, disNum)
    }    
}

function ansMem(param) {
    disExpOBJ = document.getElementById("disExp");
    var calcNum;
    var disNum;
    lastChar = disExpOBJ.value.charAt(disExpOBJ.value.length - 1);
    if (disExpOBJ.value.length > 0 && lastChar != "(" && lastChar != "+" && lastChar != "-" && lastChar != "x" && lastChar != "/") {
        alreadyPoint = false;
        calcNum = "|*|"+param+"|";
        disNum = param;

    }else{
        alreadyPoint = false;
        calcNum = "|"+param+"|";
        disNum = param; //mettere parentesi fittizia
    }
    display(calcNum, disNum)
}

function parentesiFittizie(){
    expOBJ = document.getElementById("Exp");
    var par;
    for (i= 0; i < haveParentesi.length; i++) {
        if (haveParentesi[i] == ",") {
            par = "("            
        } else {
            par = haveParentesi[i]; 
        }
        expOBJ.innerHTML +="<span id='fakePar'>"+par+"</span>";
    }
}

function display(calcExp, disExp) {
    calcExpOBJ = document.getElementById("calcExp");
    disExpOBJ = document.getElementById("disExp");
    expOBJ = document.getElementById("Exp");
    document.getElementById("RetExp").style.visibility = "hidden";
    document.getElementById("Errore-Risultato").style.visibility = "hidden";
        
    calcExpOBJ.value += calcExp;
    disExpOBJ.value += disExp;
    expOBJ.innerHTML  = disExpOBJ.value;
    parentesiFittizie();
}
function ce() {
    calcExpOBJ = document.getElementById("calcExp");
    disExpOBJ = document.getElementById("disExp");
    expOBJ = document.getElementById("Exp");
    document.getElementById("RetExp").style.visibility = "hidden";
    document.getElementById("Errore-Risultato").style.visibility = "hidden";

    /*tempString =  disExpOBJ.value;
    lastChar = tempString.charAt(tempString.length-1);
    i = tempString.length;
    if (!isNaN(lastChar)) {
        i = tempString.length;

        while (!isNaN(tempString.charAt(i)) && i >= 0) {
            i--;
        }
        tempString  = tempString.substring(0,i+1); 
    }else{
        tempString  = tempString.substring(0,i-1); 
    }
console.log(tempString.substring(0,i+1))
*/

    tempString = calcExpOBJ.value
    pipeIndex = tempString.lastIndexOf("|");
    tempString = tempString.substring(0,pipeIndex);
    calcExpOBJ.value = tempString;
    disExpOBJ.value = tempString;
    expOBJ.innerHTML  = disExpOBJ.value;

}
function c() {
    calcExpOBJ = document.getElementById("calcExp");
    disExpOBJ = document.getElementById("disExp");
    expOBJ = document.getElementById("Exp");
    document.getElementById("RetExp").style.visibility = "hidden";
    document.getElementById("Errore-Risultato").style.visibility = "hidden";
        
    calcExpOBJ.value = "";
    disExpOBJ.value = "";
    expOBJ.innerHTML  = "0";
}

//numeri by tastiera trigger