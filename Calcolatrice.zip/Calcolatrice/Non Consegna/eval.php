<?php
/*$a = "sqrt(sqrt(sqrt(2)))";
eval('$result = '.$a.';');
//echo $result;
$a = "ciao";
//echo $a[2];
echo "<br><br>";
//test potenza, la condizione non verifica il caso in cui ci sia un segno ma sdi ferma al $J>0
$CleanmathExpression = "2622^d";

$i=strlen($CleanmathExpression);
while (substr_count($CleanmathExpression,"^") > 0) {
   
    $a  = strripos($CleanmathExpression,"^");
    while ( $CleanmathExpression[$j] != "(" && $CleanmathExpression[$j] != "+" && $CleanmathExpression[$j] != "^" && $CleanmathExpression[$j] != "-" && $CleanmathExpression[$j] != "/" && $CleanmathExpression[$j] != "*"  && $j>0  ) {
            echo $j."<br>";
            $j--;
        }
        $CleanmathExpression[$j] = ",";
            $tmpString = substr($CleanmathExpression, 0, $j-1)."pow(".substr($CleanmathExpression,$j-1);
    }

 

echo  $tmpString;*/

$a = array("3","2","4");
print_r($a);
unset($a[1]);
print_r(array_values($a));

?>
